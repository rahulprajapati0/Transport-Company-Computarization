let buttons =document.querySelectorAll('button');
let ids=document.querySelectorAll('tr');
for(let i=1;i<buttons.length;i++)
{
  buttons[i].addEventListener("click",async ()=>{
     
      let temp= await axios({
        method: 'post',
        url: '/axios1',
        data: {
          Id: ids[i].childNodes[1].innerHTML
        }
      });
      if(temp.data['1']==1)
      {
        window.alert(`1 Truck has became Free`)
      }
      else
      {
        window.alert(`${temp.data['1']} Trucks have became Free`)
      }
      window.location.replace("http://127.0.0.1:5000/updatedelivery");
  })
}
