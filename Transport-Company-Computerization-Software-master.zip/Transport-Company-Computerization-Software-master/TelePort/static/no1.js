let buttons =document.querySelectorAll('button');
let ids=document.querySelectorAll('tr');
for(let i=1;i<buttons.length;i++)
{
  buttons[i].addEventListener("click",async ()=>{
     
      let temp= await axios({
        method: 'post',
        url: '/axios',
        data: {
          Id: ids[i].childNodes[1].innerHTML
        }
      });
      console.log(temp)
      if(temp.data["2"]=="NO")
      {
        let cnt =temp.data["1"]
        if(cnt==1)
        {
            window.alert(`${cnt} Truck is not available in Branch ${temp.data['3']}`)
        }
        else
        {
            window.alert(`${cnt} Trucks are not available in Branch  ${temp.data['3']}`)
        }
      }
      else
      {
        let cnt =temp.data["1"]
        if(cnt==1)
        {
            window.alert(`Success ${cnt} Truck is available in Branch  ${temp.data['3']}`)
        }
        else
        {
            window.alert(`Success ${cnt} Trucks are available in Branch  ${temp.data['3']}`)
        }
      }
      window.location.replace("http://127.0.0.1:5000/assigntruck");
  })
}
