let form = document.querySelector('form');
form.addEventListener('submit',async(event)=>{
  event.preventDefault();
  let BranchId=event.srcElement[0].value
  let NewRate=event.srcElement[1].value
  if(!BranchId)
  {
    window.alert("Please Enter BranchID")
    return
  }
  if(!NewRate)
  {
    window.alert("Please Enter A rate")
    return
  }
  if(NewRate<=0)
  {
    window.alert("Please Enter A Valid Rate")
    return
  }
  console.log(BranchId,NewRate)
  let temp = await axios.post('http://127.0.0.1:5000/rate',{branchid : BranchId,newrate :NewRate})
  console.log(temp)
  if(temp.data=="okk")
  {
    window.alert("Success Rate Changed Succesfully")
  }
  else
  {
    window.alert("Please Enter A Valid Branch")
  }
})